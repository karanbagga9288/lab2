//walk the dom activity fourth
//1.) Using ol as your starting element, target the first li element 
var ol = document.querySelector('ol');
var li = ol.firstElementChild;

//4.) using the second li element as your starting element, target the next li element and change the colour to purple. 
let element2nd = document.getElementsByTagName('li')[1];
var i = 0;
var element3rd = element2nd.nextElementSibling;

while(i<element3rd.length){
element3rd[i].style.color = 'purple';
i++;
}


//3.) using html as your starting element, what is the last Element child? Console.log to check it out. 
let startingElementhtml = document.querySelector('html');

var childZ = startingElementhtml.lastElementChild;

console.log(startingElementhtml, childZ);



