//1.)  find two different ways to target the first section element on the page. Use console.log to check. Put a comment with the word faster by the method that targets the element more quickly and efficently. 
var way1st = document.querySelector('section');

var way2nd = document.getElementById('section');

console.log(way1st);//displaying and checking using console.log

console.log(way2nd);

//2)


//3.)  Target all elements with the class or orange and change the text in these elements orange 
var orange = document.getElementsByClassName('orange');
while(e<orange.length){
    var e = 0;
    orange[e].style.color = 'orange';
    e++;
}

//4.) Target all section elements and console log
var allTheSectionElements = document.querySelectorAll('section');

console.log(allTheSectionElements);


//5.) Find two ways to target the second section element 
let way1ToTarget = document.querySelectorAll('section')[1];
//two ways
var Way2ToTarget = document.getElementsByTagName('section')[1];



