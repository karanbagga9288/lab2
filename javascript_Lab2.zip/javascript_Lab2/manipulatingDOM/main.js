//1.) Add a new paragraph to the page
let mainElement = document.querySelector('main');

var newParaFirst = document.createElement('p');

newParaFirst.textContent = 'I am Javascript Student. I also like cats';

mainElement.appendChild(newParaFirst);



//4.) Remove the footer element 

//3.) Change the src attribute in the image element to 'cat2.jpg'
let cat2nd = document.getElementsByTagName("img")[0];

cat2nd.setAttribute("src", "assets/cat2.jpg");

//5.) Add an h3 into the header 
var headerElement = document.querySelector('header');

var h3Element = document.createElement('h3Element');//creating h3

h3Element.textContent = 'Cats are very cute';

headerElement.appendChild(h3Element);
